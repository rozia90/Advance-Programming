#include<stdio.h>
#include<stdlib.h>

void main(int argc, char* argv[]){
	
	printf("\narg=%s\n",argv[1]);
	printf("I am process %d\n", getpid());

}
	/*
	
*/
