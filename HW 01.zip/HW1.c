#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/shm.h>
#include<unistd.h>

void assign_random_pid(char[], char[],char[],int);

int main(){

	assign_random_pid("./winner","winner","arg1",7);

}

void assign_random_pid(char path[], char name[],char arg[],int n){

	int id, *nptr, memid;
	int newN=n+1,i,j,maxid,*nptr2,memid2;
	struct shmid_ds buff;
	
	//will allocate new shared area
	if((memid=shmget(0,sizeof(int),0666|IPC_CREAT|IPC_EXCL))<0)
	perror("cannot shmget!");
	if((nptr=(int*)shmat(memid,0,0))==(int*)-1)
	perror("cannot shmat!");
	if((memid2=shmget(0,sizeof(int),0666|IPC_CREAT|IPC_EXCL))<0)
	perror("cannot shmget!");
	if((nptr2=(int*)shmat(memid2,0,0))==(int*)-1)
	perror("cannot shmat!");

	*nptr=0;
	*nptr2=0;
	//create n processes
	for(i=0; i<newN; i++){
		//if the last process free all
		if(i==n){
			*nptr2=1;
			exit(0);
		}
		//else create new process and put them to busy wait state
		else{
			id=fork();
			if(id==0){
				printf("pid = %d\n",getpid());
				if((getpid()%n)>((*nptr)%n)){
					*nptr=getpid();
				}
				while(1){
					if(*nptr2==1){
						if(getpid()==*nptr){
							if(shmdt(nptr)<0)
								perror("cannot shmdt");
							if(shmctl(memid,IPC_RMID,&buff)<0)
								perror("cannot shmctl");
							if(shmdt(nptr2)<0)
								perror("cannot shmdt");
							if(shmctl(memid2,IPC_RMID,&buff)<0)
								perror("cannot shmctl");
							execv(path,(char *[]){name,arg,NULL});
							printf("Winner is %d\n",*nptr);
						}
						exit(0);
					}
				}
			}
		}
		sleep(1);
	}
}
